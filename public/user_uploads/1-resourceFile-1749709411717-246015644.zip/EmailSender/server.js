// =================================================================
//                      MODULE IMPORTS
// =================================================================
const express = require('express');
const nodemailer = require('nodemailer');
const ejs = require('ejs');
const path = require('path'); // <<< FIX: Correctly imported the 'path' module
require('dotenv').config();

// =================================================================
//                  EXPRESS APP INITIALIZATION
// =================================================================
const app = express();
const PORT = 3000;
// Middleware to parse JSON bodies from incoming requests
app.use(express.json());

// =================================================================
//                IN-MEMORY DATABASE (FOR DEMO)
// =================================================================
// In a real application, you would use a proper database like MongoDB, PostgreSQL, or Redis.
// The key will be the user's email.
let abandonedCarts = {};

// =================================================================
//                NODEMAILER TRANSPORTER SETUP
// =================================================================
// This transporter uses your Gmail credentials from the .env file.
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

// =================================================================
//                      EMAIL SENDING FUNCTIONS
// =================================================================

/**
 * Sends a detailed order confirmation email.
 * @param {object} orderData - The complete data for the order.
 */
async function sendOrderConfirmationEmail(orderData) {
    try {
        const emailHtml = await ejs.renderFile(path.join(__dirname, 'views/order-confirmation.ejs'), { order: orderData });
        const mailOptions = {
            from: `"Your Company Name" <${process.env.EMAIL_USER}>`,
            to: orderData.customer.email,
            subject: `Your Order Confirmation (#${orderData.orderNumber})`,
            html: emailHtml,
        };
        await transporter.sendMail(mailOptions);
        console.log(`Order confirmation sent to ${orderData.customer.email}`);
    } catch (error) {
        console.error('Error sending order confirmation email:', error);
    }
}

/**
 * Sends a reminder email for an abandoned cart.
 * @param {object} userData - The user's data (name, email).
 * @param {Array} cartItems - The array of items left in the cart.
 */
async function sendAbandonedCartEmail(userData, cartItems) {
    try {
        const emailHtml = await ejs.renderFile(path.join(__dirname, 'views/abandoned-cart.ejs'), { user: userData, cartItems: cartItems });
        const mailOptions = {
            from: `"Your Company Name" <${process.env.EMAIL_USER}>`,
            to: userData.email,
            subject: `Did you forget something? Your cart is waiting!`,
            html: emailHtml,
        };
        await transporter.sendMail(mailOptions);
        console.log(`Abandoned cart reminder sent to ${userData.email}`);
    } catch (error) {
        console.error('Error sending abandoned cart email:', error);
    }
}

// =================================================================
//                          API ROUTES / ENDPOINTS
// =================================================================

// <<< FIX: Added a root route to handle GET / requests and provide instructions.
app.get('/', (req, res) => {
    res.send(`
        <h1>Auto Email Server is Running!</h1>
        <p>This server doesn't have a visual homepage. Use the following endpoints for testing:</p>
        <ul>
            <li>
                <strong>Test Abandoned Cart:</strong> Send a <code>POST</code> request to <code>/api/save-cart</code> with a JSON body.
            </li>
            <li>
                <strong>Test Order Confirmation:</strong> Visit <a href="/place-order">/place-order</a> in your browser.
            </li>
        </ul>
    `);
});

/**
 * Endpoint to save cart information.
 * This simulates a user entering their email at checkout before paying.
 */
app.post('/api/save-cart', (req, res) => {
    const { email, name, items } = req.body;
    if (!email || !items) {
        return res.status(400).send('Email and items are required.');
    }

    console.log(`Saving cart for ${email}...`);
    abandonedCarts[email] = {
        name: name || 'Valued Customer',
        items: items,
        timestamp: new Date(),
        status: 'active' // status can be 'active', 'sent_reminder'
    };

    res.status(200).send('Cart information saved. An abandoned cart email will be sent if not purchased.');
});

/**
 * Endpoint to simulate a successful order placement.
 * This triggers the order confirmation email and cleans up the abandoned cart record.
 */
app.get('/place-order', async (req, res) => {
    // This is mock data. In a real app, this would come from your database after a successful payment.
    const mockOrderData = {
        orderNumber: '123-ABC-789',
        orderDate: new Date(),
        customer: {
            name: 'John Doe',
            email: 'your-personal-email@example.com', // <<-- IMPORTANT: Change this to your own email to receive the test.
        },
        items: [
            { name: 'Awesome T-Shirt', sku: 'TS-001', quantity: 2, price: 20.00 },
            { name: 'Cool Hat', sku: 'HT-005', quantity: 1, price: 15.50 },
        ],
        financials: {
            subtotal: 55.50,
            shipping: 5.00,
            tax: 4.85,
            grandTotal: 65.35,
        },
        shippingAddress: {
            name: 'John Doe',
            street: '123 Main St',
            city: 'Anytown',
            state: 'CA',
            zip: '12345'
        }
    };

    // Send the confirmation email
    await sendOrderConfirmationEmail(mockOrderData);

    // IMPORTANT: Remove user from abandoned cart list after purchase to prevent reminder email.
    if (abandonedCarts[mockOrderData.customer.email]) {
        console.log(`User ${mockOrderData.customer.email} completed their purchase. Deleting from abandoned list.`);
        delete abandonedCarts[mockOrderData.customer.email];
    }

    res.send('Order Placed! Confirmation email has been sent.');
});


// =================================================================
//                ABANDONED CART SCHEDULER
// =================================================================
// This function runs periodically to check for carts that need a reminder.
const CHECK_INTERVAL = 60 * 1000;      // Check every 1 minute.
const ABANDON_TIME = 1.5 * 60 * 1000;   // Set to 1.5 minutes for easy testing. Change to 60 * 60 * 1000 for 1 hour in production.

setInterval(() => {
    console.log('\n[Scheduler] Checking for abandoned carts...');
    const now = new Date();

    for (const email in abandonedCarts) {
        const cart = abandonedCarts[email];
        const timeDiff = now - new Date(cart.timestamp);

        // Check if cart is older than ABANDON_TIME and a reminder hasn't been sent yet.
        if (timeDiff > ABANDON_TIME && cart.status === 'active') {
            console.log(`[Scheduler] Found an abandoned cart for ${email}. Sending reminder...`);
            
            const userData = { email: email, name: cart.name };
            sendAbandonedCartEmail(userData, cart.items);

            // Update status to avoid sending multiple emails for the same cart.
            cart.status = 'sent_reminder';
        }
    }
}, CHECK_INTERVAL);

// =================================================================
//                        START THE SERVER
// =================================================================
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});